"""
Wishkit 상품 추출 엔진 — AI 완전 의존 방식 서버.

engine-ai-prototype(2026-09-18 결정: 몰별 DOM 규칙 폐기, 서버 AI가 상품 페이지를 읽어 구조화
추출)에서 골든셋 36개로 검증한 파이프라인을 HTTP 서버로 감싼 것.

흐름: POST /extract {url} → 렌더링(공유 브라우저, 새 컨텍스트) → cleaned_html을 Gemini에 전달
→ ambiguous면 스크린샷으로 Gemini 비전 재시도 → 그라운딩 체크 → JSON 응답.

실행: `uvicorn main:app --host 0.0.0.0 --port 8000` (.env에 GEMINI_API_KEY 필요 — .env.example 참고).
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from playwright.async_api import async_playwright
from pydantic import BaseModel, HttpUrl

import config
from cache import CachedExtraction, NoOpCache, normalize_cache_key
from compare import grounding_check
from metrics import PeakRSSSampler, now_ms
from providers import ProviderResult, call_gemini, call_gemini_vision
from render import launch_browser, render

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("extract-server")

CACHE_TTL_S = 3600


class ExtractRequest(BaseModel):
    url: HttpUrl


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 브라우저는 요청마다 띄우지 않고 앱 생명주기 동안 재사용한다.
    async with async_playwright() as playwright:
        browser = await launch_browser(playwright)
        app.state.browser = browser
        app.state.gemini_semaphore = asyncio.Semaphore(config.GEMINI_MAX_CONCURRENCY)
        app.state.render_semaphore = asyncio.Semaphore(config.RENDER_MAX_CONCURRENCY)
        app.state.cache = NoOpCache()  # 실제 캐시 백엔드는 아직 미구현
        logger.info(
            "서버 시작 — 브라우저 준비 완료 (GEMINI_MAX_CONCURRENCY=%s, RENDER_MAX_CONCURRENCY=%s, EXTRACT_TIMEOUT_S=%s)",
            config.GEMINI_MAX_CONCURRENCY, config.RENDER_MAX_CONCURRENCY, config.EXTRACT_TIMEOUT_S,
        )
        try:
            yield
        finally:
            await browser.close()
            logger.info("서버 종료 — 브라우저 정리 완료")


app = FastAPI(title="wishkit-ai-extraction-engine", lifespan=lifespan)


async def _run_gemini(fn, *args) -> tuple[ProviderResult, int]:
    """동시 Gemini 호출 수를 세마포어로 제한하고, 동기 함수(내부 time.sleep 재시도)를
    스레드에서 돌린다. (결과, 소요 ms)를 반환한다."""
    started = now_ms()
    async with app.state.gemini_semaphore:
        result = await asyncio.to_thread(fn, *args)
    return result, now_ms() - started


async def _extract(url: str) -> dict:
    """렌더링 실패/차단/AI 호출 실패는 HTTPException(502)으로 올린다.
    ambiguous:true는 정상 결과이지 에러가 아니다."""
    t_start = now_ms()
    cache_key = normalize_cache_key(url)
    cached = await app.state.cache.get(cache_key)
    if cached is not None:
        return {**cached.data, "metrics": {**cached.data.get("metrics", {}), "cache_hit": True}}

    async with app.state.render_semaphore:
        r = await render(app.state.browser, url, nav_timeout_ms=config.RENDER_NAV_TIMEOUT_MS)
    render_elapsed_ms = now_ms() - t_start

    if r.error:
        raise HTTPException(502, f"렌더링 오류: {r.error}")
    if r.blocked:
        raise HTTPException(502, f"상품 페이지 접근이 차단됨(final_url={r.final_url})")

    text_result, text_elapsed_ms = await _run_gemini(call_gemini, r.cleaned_html)
    if not text_result.ok or not text_result.data:
        raise HTTPException(502, f"AI 호출 실패: {text_result.error}")
    extracted = text_result.data

    screenshot_fallback_used = False
    vision_elapsed_ms = 0
    if extracted.get("ambiguous") and r.screenshot:
        vision_result, vision_elapsed_ms = await _run_gemini(
            call_gemini_vision, r.screenshot, r.image_candidates
        )
        if vision_result.ok and vision_result.data:
            extracted = vision_result.data
            screenshot_fallback_used = True
        else:
            logger.warning("스크린샷 폴백 실패(%s) — 텍스트 결과를 그대로 사용", vision_result.error)

    response = {
        **extracted,
        "grounding": grounding_check(extracted, r.raw_text, r.image_candidates),
        "screenshot_fallback_used": screenshot_fallback_used,
        "render": {"ok": r.ok, "blocked": r.blocked, "final_url": r.final_url},
        "metrics": {
            "total_elapsed_ms": now_ms() - t_start,
            "render_elapsed_ms": render_elapsed_ms,
            "gemini_text_elapsed_ms": text_elapsed_ms,
            "gemini_vision_elapsed_ms": vision_elapsed_ms,
            "cache_hit": False,
        },
    }
    await app.state.cache.set(
        cache_key, CachedExtraction(data=response, cached_at_ms=now_ms()), ttl_seconds=CACHE_TTL_S
    )
    return response


@app.post("/extract")
async def extract(req: ExtractRequest):
    url = str(req.url)
    async with PeakRSSSampler(interval_ms=config.RSS_SAMPLE_INTERVAL_MS) as sampler:
        try:
            result = await asyncio.wait_for(_extract(url), timeout=config.EXTRACT_TIMEOUT_S)
        except TimeoutError:
            raise HTTPException(
                504, f"요청 처리 시간이 {config.EXTRACT_TIMEOUT_S}초를 넘어 취소됨: {url}"
            ) from None
        except HTTPException:
            raise
        except Exception as exc:
            logger.exception("알 수 없는 오류: %s", url)
            raise HTTPException(500, f"{type(exc).__name__}: {exc}") from exc

    result["metrics"]["peak_rss_mb"] = round(sampler.peak_rss_mb, 1)
    return result


@app.get("/healthz")
async def healthz():
    return {"ok": True, "browser_connected": app.state.browser.is_connected()}
