"""서버 설정값 — 전부 환경변수로 오버라이드 가능하다."""
from __future__ import annotations

import os

from dotenv import load_dotenv

# .env는 설정을 읽기 전에 여기서 로드한다 — 어떤 모듈이 config를 먼저 import하든 순서가 안 꼬이게.
load_dotenv()


def _int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


# Gemini 인증/모델. providers.py가 여기 값만 본다.
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.5-flash-lite")

# 요청 하나(렌더링 + Gemini 호출 + 필요시 스크린샷 폴백)의 전체 타임아웃. 넘기면 504로
# 응답하고 그 요청만 취소한다.
EXTRACT_TIMEOUT_S = float(os.environ.get("EXTRACT_TIMEOUT_S", "45"))

# Playwright page.goto()의 네비게이션 타임아웃.
RENDER_NAV_TIMEOUT_MS = _int("RENDER_NAV_TIMEOUT_MS", 20000)

# 동시 render() 호출 수 상한. 동시 요청 1건당 peak RSS가 +400~650MB 늘어나는 게 실측돼서
# (REPORT_2026-09-19.md 2절) 브라우저 컨텍스트 수를 이 값 이하로 묶는다.
RENDER_MAX_CONCURRENCY = _int("RENDER_MAX_CONCURRENCY", 6)

# Gemini 429 재시도 최대 횟수.
GEMINI_MAX_RETRIES = _int("GEMINI_MAX_RETRIES", 4)

# 동시 Gemini 호출 수 상한. 2026-09-29 Tier 1(유료) 전환에 맞춰 3→6으로 올려
# RENDER_MAX_CONCURRENCY와 맞췄다. 무료 티어면 3 권장(근거: REPORT_FARGATE_VALIDATION_
# 2026-09-24.md §4 — 태스크를 늘려도 계정 전체 RPM을 나눠 쓰므로 병목이 그대로였음).
GEMINI_MAX_CONCURRENCY = _int("GEMINI_MAX_CONCURRENCY", 6)

# 요청별 peak RSS 샘플링 주기 (metrics.py).
RSS_SAMPLE_INTERVAL_MS = _int("RSS_SAMPLE_INTERVAL_MS", 100)
